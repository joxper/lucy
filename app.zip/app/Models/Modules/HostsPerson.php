<?php

namespace App\Models\Modules;

use App\Lucy\Model;

class HostsPerson extends Model
{
    /**
     * {@inheritDoc}
     */
    protected $table = 'hosts_people';

    /**
     * {@inheritDoc}
     */
    protected $fillable = [
        'host_id', 'people_id',
    ];

    /**
     * {@inheritDoc}
     */
    protected $primaryKey = 'id';

    public function host()
    {
        return $this->belongsTo(Host::class, 'host_id');
    }

    public function people()
    {
        return $this->belongsTo(User::class, 'people_id');
    }
}
