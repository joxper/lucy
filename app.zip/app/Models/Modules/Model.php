<?php

namespace App\Models\Modules;

use App\Lucy\Model;

class Model extends Model
{
    /**
     * {@inheritDoc}
     */
    protected $table = 'models';

    /**
     * {@inheritDoc}
     */
    protected $fillable = [
        'manufacter_id', 'name',
    ];

    /**
     * {@inheritDoc}
     */
    protected $primaryKey = 'id';

    public function manufacter()
    {
        return $this->belongsTo(Manufacturer::class, 'manufacter_id');
    }
}
