<?php

namespace App\Models\Modules;

use App\Lucy\Model;

class ProjectsAdmin extends Model
{
    /**
     * {@inheritDoc}
     */
    protected $table = 'projects_admins';

    /**
     * {@inheritDoc}
     */
    protected $fillable = [
        'project_id', 'admin_id',
    ];

    /**
     * {@inheritDoc}
     */
    protected $primaryKey = 'id';

    public function project()
    {
        return $this->belongsTo(Project::class, 'project_id');
    }

    public function admin()
    {
        return $this->belongsTo(User::class, 'admin_id');
    }
}
