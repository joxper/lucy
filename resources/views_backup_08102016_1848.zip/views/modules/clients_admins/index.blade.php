@extends('layouts.list')

@section('title', 'ClientsAdmins')

@section('page-header', 'ClientsAdmins <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-adn"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">ClientsAdmins</li>
    </ol>
@endsection

@section('table-name', 'ClientsAdmins List')

@section('add-link', action('Modules\ClientsAdminController@create'))

@section('table-id', 'clients_admins-table')

@section('table-th')
    <th class="center-align">Adminid</th>
    <th class="center-align">Clientid</th>
@endsection

@section('ajax-datatables', action('Modules\ClientsAdminController@datatables'))

@section('datatables-columns')
    {data: 'adminid', name: 'adminid'},
    {data: 'clientid', name: 'clientid'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection