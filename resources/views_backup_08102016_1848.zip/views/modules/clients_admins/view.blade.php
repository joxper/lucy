@extends('layouts.view')

@section('title', trans('lucy.word.view').' - ClientsAdmins')

@section('page-header', 'ClientsAdmins <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-adn"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\ClientsAdminController@index') !!}">ClientsAdmins</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'adminid', 'Adminid', $data['adminid']) !!}
    {!! Form::group('static', 'clientid', 'Clientid', $data['clientid']) !!}
@endsection