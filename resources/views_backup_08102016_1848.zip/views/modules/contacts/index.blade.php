@extends('layouts.list')

@section('title', 'Contacts')

@section('page-header', 'Contacts <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-envelope"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">Contacts</li>
    </ol>
@endsection

@section('table-name', 'Contacts List')

@section('add-link', action('Modules\ContactController@create'))

@section('table-id', 'contacts-table')

@section('table-th')
    <th class="center-align">Name</th>
    <th class="center-align">Email</th>
@endsection

@section('ajax-datatables', action('Modules\ContactController@datatables'))

@section('datatables-columns')
    {data: 'name', name: 'name'},
    {data: 'email', name: 'email'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection