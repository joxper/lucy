@extends('layouts.list')

@section('title', 'Hosts')

@section('page-header', 'Hosts <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-heartbeat"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">Hosts</li>
    </ol>
@endsection

@section('table-name', 'Hosts List')

@section('add-link', action('Modules\HostController@create'))

@section('table-id', 'hosts-table')

@section('table-th')
    <th class="center-align">Client Id</th>
    <th class="center-align">Name</th>
    <th class="center-align">Address</th>
    <th class="center-align">Status</th>
@endsection

@section('ajax-datatables', action('Modules\HostController@datatables'))

@section('datatables-columns')
    {data: 'client_id', name: 'client_id'},
    {data: 'name', name: 'name'},
    {data: 'address', name: 'address'},
    {data: 'status', name: 'status'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection