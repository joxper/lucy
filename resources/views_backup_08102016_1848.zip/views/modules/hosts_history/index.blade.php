@extends('layouts.list')

@section('title', 'HostsHistory')

@section('page-header', 'HostsHistory <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-history"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">HostsHistory</li>
    </ol>
@endsection

@section('table-name', 'HostsHistory List')

@section('add-link', action('Modules\HostsHistoryController@create'))

@section('table-id', 'hosts_history-table')

@section('table-th')
    <th class="center-align">Check Id</th>
    <th class="center-align">Status</th>
    <th class="center-align">Latency</th>
    <th class="center-align">Timestamp</th>
@endsection

@section('ajax-datatables', action('Modules\HostsHistoryController@datatables'))

@section('datatables-columns')
    {data: 'check_id', name: 'check_id'},
    {data: 'status', name: 'status'},
    {data: 'latency', name: 'latency'},
    {data: 'timestamp', name: 'timestamp'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection