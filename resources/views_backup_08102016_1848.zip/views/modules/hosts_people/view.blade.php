@extends('layouts.view')

@section('title', trans('lucy.word.view').' - HostsPeople')

@section('page-header', 'HostsPeople <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-user-plus"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\HostsPersonController@index') !!}">HostsPeople</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'host_id', 'Host Id', $data['host_id']) !!}
    {!! Form::group('static', 'people_id', 'People Id', $data['people_id']) !!}
@endsection