@extends('layouts.list')

@section('title', 'LogsEmail')

@section('page-header', 'LogsEmail <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-envelope-square"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">LogsEmail</li>
    </ol>
@endsection

@section('table-name', 'LogsEmail List')

@section('add-link', action('Modules\LogsEmailController@create'))

@section('table-id', 'logs_email-table')

@section('table-th')
    <th class="center-align">User Id</th>
    <th class="center-align">Client Id</th>
    <th class="center-align">To</th>
    <th class="center-align">Subject</th>
    <th class="center-align">Message</th>
    <th class="center-align">Timestamp</th>
@endsection

@section('ajax-datatables', action('Modules\LogsEmailController@datatables'))

@section('datatables-columns')
    {data: 'user_id', name: 'user_id'},
    {data: 'client_id', name: 'client_id'},
    {data: 'to', name: 'to'},
    {data: 'subject', name: 'subject'},
    {data: 'message', name: 'message'},
    {data: 'timestamp', name: 'timestamp'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection