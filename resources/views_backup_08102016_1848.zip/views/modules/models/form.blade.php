@extends('layouts.form')

@section('title', $title.' - Models')

@section('page-header', 'Models <small>'.$title.'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-laptop"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\ModelController@index') !!}">Models</a></li>
        <li class="active">{{ $title }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('select', 'manufacter_id', 'Manufacter Id', $data['manufacter_id'], ['options' => DB::table('manufacturers')->orderBy('id')->lists('id', 'id')]) !!}
    {!! Form::group('text', 'name', 'Name', $data['name']) !!}
@endsection

@section('scripts')
    <script src="{!! url('vendor/jsvalidation/js/jsvalidation.js')!!}"></script>
    {!! JsValidator::formRequest('App\Http\Requests\Modules\ModelRequest') !!}
@endsection