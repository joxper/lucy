@extends('layouts.list')

@section('title', 'Models')

@section('page-header', 'Models <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-laptop"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">Models</li>
    </ol>
@endsection

@section('table-name', 'Models List')

@section('add-link', action('Modules\ModelController@create'))

@section('table-id', 'models-table')

@section('table-th')
    <th class="center-align">Manufacter Id</th>
    <th class="center-align">Name</th>
@endsection

@section('ajax-datatables', action('Modules\ModelController@datatables'))

@section('datatables-columns')
    {data: 'manufacter_id', name: 'manufacter_id'},
    {data: 'name', name: 'name'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection