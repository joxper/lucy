@extends('layouts.list')

@section('title', 'NotificationTemplates')

@section('page-header', 'NotificationTemplates <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-paper-plane"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">NotificationTemplates</li>
    </ol>
@endsection

@section('table-name', 'NotificationTemplates List')

@section('add-link', action('Modules\NotificationTemplateController@create'))

@section('table-id', 'notification_templates-table')

@section('table-th')
    <th class="center-align">Name</th>
    <th class="center-align">Subject</th>
    <th class="center-align">Message</th>
    <th class="center-align">Info</th>
    <th class="center-align">Sms</th>
@endsection

@section('ajax-datatables', action('Modules\NotificationTemplateController@datatables'))

@section('datatables-columns')
    {data: 'name', name: 'name'},
    {data: 'subject', name: 'subject'},
    {data: 'message', name: 'message'},
    {data: 'info', name: 'info'},
    {data: 'sms', name: 'sms'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection