@extends('layouts.list')

@section('title', 'Projects')

@section('page-header', 'Projects <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-lightbulb-o"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">Projects</li>
    </ol>
@endsection

@section('table-name', 'Projects List')

@section('add-link', action('Modules\ProjectController@create'))

@section('table-id', 'projects-table')

@section('table-th')
    <th class="center-align">Client Id</th>
    <th class="center-align">Tag</th>
    <th class="center-align">Name</th>
    <th class="center-align">Notes</th>
    <th class="center-align">Description</th>
    <th class="center-align">Startdate</th>
    <th class="center-align">Deadline</th>
    <th class="center-align">Progress</th>
@endsection

@section('ajax-datatables', action('Modules\ProjectController@datatables'))

@section('datatables-columns')
    {data: 'client_id', name: 'client_id'},
    {data: 'tag', name: 'tag'},
    {data: 'name', name: 'name'},
    {data: 'notes', name: 'notes'},
    {data: 'description', name: 'description'},
    {data: 'startdate', name: 'startdate'},
    {data: 'deadline', name: 'deadline'},
    {data: 'progress', name: 'progress'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection