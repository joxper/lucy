@extends('layouts.view')

@section('title', trans('lucy.word.view').' - Projects')

@section('page-header', 'Projects <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-lightbulb-o"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\ProjectController@index') !!}">Projects</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'client_id', 'Client Id', $data['client_id']) !!}
    {!! Form::group('static', 'tag', 'Tag', $data['tag']) !!}
    {!! Form::group('static', 'name', 'Name', $data['name']) !!}
    {!! Form::group('static', 'notes', 'Notes', nl2br($data['notes'])) !!}
    {!! Form::group('static', 'description', 'Description', nl2br($data['description'])) !!}
    {!! Form::group('static', 'startdate', 'Startdate', $data['startdate']) !!}
    {!! Form::group('static', 'deadline', 'Deadline', $data['deadline']) !!}
    {!! Form::group('static', 'progress', 'Progress', $data['progress']) !!}
@endsection