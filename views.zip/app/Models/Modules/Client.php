<?php

namespace App\Models\Modules;

use App\Lucy\Model;

class Client extends Model
{
    /**
     * {@inheritDoc}
     */
    protected $table = 'clients';

    /**
     * {@inheritDoc}
     */
    protected $fillable = [
        'name', 'asset_tag_prefix', 'license_tag_prefix',
    ];

    /**
     * {@inheritDoc}
     */
    protected $primaryKey = 'id';
}
