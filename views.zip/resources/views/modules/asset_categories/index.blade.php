@extends('layouts.list')

@section('title', 'AssetCategories')

@section('page-header', 'AssetCategories <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-dropbox"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">AssetCategories</li>
    </ol>
@endsection

@section('table-name', 'AssetCategories List')

@section('add-link', action('Modules\AssetCategoryController@create'))

@section('table-id', 'asset_categories-table')

@section('table-th')
    <th class="center-align">Name</th>
    <th class="center-align">Color</th>
@endsection

@section('ajax-datatables', action('Modules\AssetCategoryController@datatables'))

@section('datatables-columns')
    {data: 'name', name: 'name'},
    {data: 'color', name: 'color'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection