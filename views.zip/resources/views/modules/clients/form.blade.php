@extends('layouts.form')

@section('title', $title.' - Clients')

@section('page-header', 'Clients <small>'.$title.'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-suitcase"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\ClientController@index') !!}">Clients</a></li>
        <li class="active">{{ $title }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('text', 'name', 'Name', $data['name']) !!}
    {!! Form::group('text', 'asset_tag_prefix', 'Asset Tag Prefix', $data['asset_tag_prefix']) !!}
    {!! Form::group('text', 'license_tag_prefix', 'License Tag Prefix', $data['license_tag_prefix']) !!}
@endsection

@section('scripts')
    <script src="{!! url('vendor/jsvalidation/js/jsvalidation.js')!!}"></script>
    {!! JsValidator::formRequest('App\Http\Requests\Modules\ClientRequest') !!}
@endsection