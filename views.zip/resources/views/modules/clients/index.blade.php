@extends('layouts.list')

@section('title', 'Clients')

@section('page-header', 'Clients <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-suitcase"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">Clients</li>
    </ol>
@endsection

@section('table-name', 'Clients List')

@section('add-link', action('Modules\ClientController@create'))

@section('table-id', 'clients-table')

@section('table-th')
    <th class="center-align">Name</th>
    <th class="center-align">Asset Tag Prefix</th>
    <th class="center-align">License Tag Prefix</th>
@endsection

@section('ajax-datatables', action('Modules\ClientController@datatables'))

@section('datatables-columns')
    {data: 'name', name: 'name'},
    {data: 'asset_tag_prefix', name: 'asset_tag_prefix'},
    {data: 'license_tag_prefix', name: 'license_tag_prefix'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection