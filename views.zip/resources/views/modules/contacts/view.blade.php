@extends('layouts.view')

@section('title', trans('lucy.word.view').' - Contacts')

@section('page-header', 'Contacts <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-envelope"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\ContactController@index') !!}">Contacts</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'name', 'Name', $data['name']) !!}
    {!! Form::group('static', 'email', 'Email', $data['email']) !!}
@endsection