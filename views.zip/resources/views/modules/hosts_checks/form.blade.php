@extends('layouts.form')

@section('title', $title.' - HostsChecks')

@section('header')
    {!! Html::style('bower_components/bootstrap-switch/dist/css/bootstrap3/bootstrap-switch.min.css') !!}
    {!! Html::style('bower_components/bootstrap-switch/dist/css/bootstrap3/bootstrap-switch.min.css') !!}
    {!! Html::style('bower_components/bootstrap-switch/dist/css/bootstrap3/bootstrap-switch.min.css') !!}
@endsection

@section('page-header', 'HostsChecks <small>'.$title.'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-check"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\HostsCheckController@index') !!}">HostsChecks</a></li>
        <li class="active">{{ $title }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('select', 'host_id', 'Host Id', $data['host_id'], ['options' => DB::table('hosts')->orderBy('id')->lists('id', 'id')]) !!}
    {!! Form::group('text', 'name', 'Name', $data['name']) !!}
    {!! Form::group('text', 'type', 'Type', $data['type']) !!}
    {!! Form::group('text', 'port', 'Port', $data['port']) !!}
    {!! Form::checkRadio('checkbox', 'monitoring', 'Monitoring', true, ['class' => 'switch', 'checked' => $data['monitoring'], 'data-on-text' => trans('lucy.word.yes'), 'data-off-text' => trans('lucy.word.no')]) !!}
    {!! Form::checkRadio('checkbox', 'email', 'Email', true, ['class' => 'switch', 'checked' => $data['email'], 'data-on-text' => trans('lucy.word.yes'), 'data-off-text' => trans('lucy.word.no')]) !!}
    {!! Form::checkRadio('checkbox', 'sms', 'Sms', true, ['class' => 'switch', 'checked' => $data['sms'], 'data-on-text' => trans('lucy.word.yes'), 'data-off-text' => trans('lucy.word.no')]) !!}
    {!! Form::group('text', 'status', 'Status', $data['status']) !!}
@endsection

@section('scripts')
    <script src="{!! url('vendor/jsvalidation/js/jsvalidation.js')!!}"></script>
    {!! JsValidator::formRequest('App\Http\Requests\Modules\HostsCheckRequest') !!}
    {!! Html::script('bower_components/bootstrap-switch/dist/js/bootstrap-switch.min.js') !!}
    {!! Html::script('bower_components/bootstrap-switch/dist/js/bootstrap-switch.min.js') !!}
    {!! Html::script('bower_components/bootstrap-switch/dist/js/bootstrap-switch.min.js') !!}

    <script>
        $(document).ready(function () {
            $('.switch').bootstrapSwitch({
                size: 'small'
            });

            $('.switch').bootstrapSwitch({
                size: 'small'
            });

            $('.switch').bootstrapSwitch({
                size: 'small'
            });
        });
    </script>
@endsection