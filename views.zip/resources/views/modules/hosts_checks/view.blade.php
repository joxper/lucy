@extends('layouts.view')

@section('title', trans('lucy.word.view').' - HostsChecks')

@section('page-header', 'HostsChecks <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-check"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\HostsCheckController@index') !!}">HostsChecks</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'host_id', 'Host Id', $data['host_id']) !!}
    {!! Form::group('static', 'name', 'Name', $data['name']) !!}
    {!! Form::group('static', 'type', 'Type', $data['type']) !!}
    {!! Form::group('static', 'port', 'Port', $data['port']) !!}
    {!! Form::group('static', 'monitoring', 'Monitoring', $data['monitoring']) !!}
    {!! Form::group('static', 'email', 'Email', $data['email']) !!}
    {!! Form::group('static', 'sms', 'Sms', $data['sms']) !!}
    {!! Form::group('static', 'status', 'Status', $data['status']) !!}
@endsection