@extends('layouts.form')

@section('title', $title.' - HostsHistory')

@section('page-header', 'HostsHistory <small>'.$title.'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-history"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\HostsHistoryController@index') !!}">HostsHistory</a></li>
        <li class="active">{{ $title }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('select', 'check_id', 'Check Id', $data['check_id'], ['options' => DB::table('hosts_checks')->orderBy('id')->lists('id', 'id')]) !!}
    {!! Form::group('text', 'status', 'Status', $data['status']) !!}
    {!! Form::group('text', 'latency', 'Latency', $data['latency']) !!}
    {!! Form::group('text', 'timestamp', 'Timestamp', $data['timestamp']) !!}
@endsection

@section('scripts')
    <script src="{!! url('vendor/jsvalidation/js/jsvalidation.js')!!}"></script>
    {!! JsValidator::formRequest('App\Http\Requests\Modules\HostsHistoryRequest') !!}
@endsection