@extends('layouts.view')

@section('title', trans('lucy.word.view').' - HostsHistory')

@section('page-header', 'HostsHistory <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-history"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\HostsHistoryController@index') !!}">HostsHistory</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'check_id', 'Check Id', $data['check_id']) !!}
    {!! Form::group('static', 'status', 'Status', $data['status']) !!}
    {!! Form::group('static', 'latency', 'Latency', $data['latency']) !!}
    {!! Form::group('static', 'timestamp', 'Timestamp', $data['timestamp']) !!}
@endsection