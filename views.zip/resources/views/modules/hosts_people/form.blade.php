@extends('layouts.form')

@section('title', $title.' - HostsPeople')

@section('page-header', 'HostsPeople <small>'.$title.'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-user-plus"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\HostsPersonController@index') !!}">HostsPeople</a></li>
        <li class="active">{{ $title }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('select', 'host_id', 'Host Id', $data['host_id'], ['options' => DB::table('hosts')->orderBy('id')->lists('id', 'id')]) !!}
    {!! Form::group('select', 'people_id', 'People Id', $data['people_id'], ['options' => DB::table('users')->orderBy('id')->lists('id', 'id')]) !!}
@endsection

@section('scripts')
    <script src="{!! url('vendor/jsvalidation/js/jsvalidation.js')!!}"></script>
    {!! JsValidator::formRequest('App\Http\Requests\Modules\HostsPersonRequest') !!}
@endsection