@extends('layouts.list')

@section('title', 'HostsPeople')

@section('page-header', 'HostsPeople <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-user-plus"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">HostsPeople</li>
    </ol>
@endsection

@section('table-name', 'HostsPeople List')

@section('add-link', action('Modules\HostsPersonController@create'))

@section('table-id', 'hosts_people-table')

@section('table-th')
    <th class="center-align">Host Id</th>
    <th class="center-align">People Id</th>
@endsection

@section('ajax-datatables', action('Modules\HostsPersonController@datatables'))

@section('datatables-columns')
    {data: 'host_id', name: 'host_id'},
    {data: 'people_id', name: 'people_id'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection