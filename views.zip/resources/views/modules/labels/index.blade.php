@extends('layouts.list')

@section('title', 'Labels')

@section('page-header', 'Labels <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-tags"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">Labels</li>
    </ol>
@endsection

@section('table-name', 'Labels List')

@section('add-link', action('Modules\LabelController@create'))

@section('table-id', 'labels-table')

@section('table-th')
    <th class="center-align">Name</th>
    <th class="center-align">Color</th>
@endsection

@section('ajax-datatables', action('Modules\LabelController@datatables'))

@section('datatables-columns')
    {data: 'name', name: 'name'},
    {data: 'color', name: 'color'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection