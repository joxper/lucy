@extends('layouts.list')

@section('title', 'LicenseCategories')

@section('page-header', 'LicenseCategories <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-dropbox"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">LicenseCategories</li>
    </ol>
@endsection

@section('table-name', 'LicenseCategories List')

@section('add-link', action('Modules\LicenseCategoryController@create'))

@section('table-id', 'license_categories-table')

@section('table-th')
    <th class="center-align">Name</th>
    <th class="center-align">Color</th>
@endsection

@section('ajax-datatables', action('Modules\LicenseCategoryController@datatables'))

@section('datatables-columns')
    {data: 'name', name: 'name'},
    {data: 'color', name: 'color'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection