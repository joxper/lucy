@extends('layouts.list')

@section('title', 'Licenses')

@section('page-header', 'Licenses <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-certificate"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">Licenses</li>
    </ol>
@endsection

@section('table-name', 'Licenses List')

@section('add-link', action('Modules\LicenseController@create'))

@section('table-id', 'licenses-table')

@section('table-th')
    <th class="center-align">Client Id</th>
    <th class="center-align">Status Id</th>
    <th class="center-align">Category Id</th>
    <th class="center-align">Supplier Id</th>
    <th class="center-align">Tag</th>
    <th class="center-align">Name</th>
    <th class="center-align">Serial</th>
    <th class="center-align">Notes</th>
@endsection

@section('ajax-datatables', action('Modules\LicenseController@datatables'))

@section('datatables-columns')
    {data: 'client_id', name: 'client_id'},
    {data: 'status_id', name: 'status_id'},
    {data: 'category_id', name: 'category_id'},
    {data: 'supplier_id', name: 'supplier_id'},
    {data: 'tag', name: 'tag'},
    {data: 'name', name: 'name'},
    {data: 'serial', name: 'serial'},
    {data: 'notes', name: 'notes'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection