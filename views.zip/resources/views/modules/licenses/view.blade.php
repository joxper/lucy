@extends('layouts.view')

@section('title', trans('lucy.word.view').' - Licenses')

@section('page-header', 'Licenses <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-certificate"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\LicenseController@index') !!}">Licenses</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'client_id', 'Client Id', $data['client_id']) !!}
    {!! Form::group('static', 'status_id', 'Status Id', $data['status_id']) !!}
    {!! Form::group('static', 'category_id', 'Category Id', $data['category_id']) !!}
    {!! Form::group('static', 'supplier_id', 'Supplier Id', $data['supplier_id']) !!}
    {!! Form::group('static', 'tag', 'Tag', $data['tag']) !!}
    {!! Form::group('static', 'name', 'Name', $data['name']) !!}
    {!! Form::group('static', 'serial', 'Serial', $data['serial']) !!}
    {!! Form::group('static', 'notes', 'Notes', nl2br($data['notes'])) !!}
@endsection