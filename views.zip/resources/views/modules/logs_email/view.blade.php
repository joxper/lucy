@extends('layouts.view')

@section('title', trans('lucy.word.view').' - LogsEmail')

@section('page-header', 'LogsEmail <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-envelope-square"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\LogsEmailController@index') !!}">LogsEmail</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'user_id', 'User Id', $data['user_id']) !!}
    {!! Form::group('static', 'client_id', 'Client Id', $data['client_id']) !!}
    {!! Form::group('static', 'to', 'To', $data['to']) !!}
    {!! Form::group('static', 'subject', 'Subject', $data['subject']) !!}
    {!! Form::group('static', 'message', 'Message', nl2br($data['message'])) !!}
    {!! Form::group('static', 'timestamp', 'Timestamp', $data['timestamp']) !!}
@endsection