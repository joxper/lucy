@extends('layouts.view')

@section('title', trans('lucy.word.view').' - LogsSms')

@section('page-header', 'LogsSms <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-mobile-phone"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\LogsSmController@index') !!}">LogsSms</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'user_id', 'User Id', $data['user_id']) !!}
    {!! Form::group('static', 'client_id', 'Client Id', $data['client_id']) !!}
    {!! Form::group('static', 'mobile', 'Mobile', $data['mobile']) !!}
    {!! Form::group('static', 'sms', 'Sms', $data['sms']) !!}
    {!! Form::group('static', 'timestamp', 'Timestamp', $data['timestamp']) !!}
@endsection