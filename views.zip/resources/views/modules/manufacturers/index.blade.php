@extends('layouts.list')

@section('title', 'Manufacturers')

@section('page-header', 'Manufacturers <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-simplybuilt"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">Manufacturers</li>
    </ol>
@endsection

@section('table-name', 'Manufacturers List')

@section('add-link', action('Modules\ManufacturerController@create'))

@section('table-id', 'manufacturers-table')

@section('table-th')
    <th class="center-align">Name</th>
@endsection

@section('ajax-datatables', action('Modules\ManufacturerController@datatables'))

@section('datatables-columns')
    {data: 'name', name: 'name'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection