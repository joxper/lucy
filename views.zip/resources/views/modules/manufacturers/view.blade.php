@extends('layouts.view')

@section('title', trans('lucy.word.view').' - Manufacturers')

@section('page-header', 'Manufacturers <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-simplybuilt"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\ManufacturerController@index') !!}">Manufacturers</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'name', 'Name', $data['name']) !!}
@endsection