@extends('layouts.view')

@section('title', trans('lucy.word.view').' - Models')

@section('page-header', 'Models <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-laptop"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\ModelController@index') !!}">Models</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'manufacter_id', 'Manufacter Id', $data['manufacter_id']) !!}
    {!! Form::group('static', 'name', 'Name', $data['name']) !!}
@endsection