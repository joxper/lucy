@extends('layouts.form')

@section('title', $title.' - NotificationTemplates')

@section('page-header', 'NotificationTemplates <small>'.$title.'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-paper-plane"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\NotificationTemplateController@index') !!}">NotificationTemplates</a></li>
        <li class="active">{{ $title }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('text', 'name', 'Name', $data['name']) !!}
    {!! Form::group('text', 'subject', 'Subject', $data['subject']) !!}
    {!! Form::group('textarea', 'message', 'Message', $data['message']) !!}
    {!! Form::group('textarea', 'info', 'Info', $data['info']) !!}
    {!! Form::group('text', 'sms', 'Sms', $data['sms']) !!}
@endsection

@section('scripts')
    <script src="{!! url('vendor/jsvalidation/js/jsvalidation.js')!!}"></script>
    {!! JsValidator::formRequest('App\Http\Requests\Modules\NotificationTemplateRequest') !!}
@endsection