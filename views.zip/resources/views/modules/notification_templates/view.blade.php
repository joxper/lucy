@extends('layouts.view')

@section('title', trans('lucy.word.view').' - NotificationTemplates')

@section('page-header', 'NotificationTemplates <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-paper-plane"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\NotificationTemplateController@index') !!}">NotificationTemplates</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'name', 'Name', $data['name']) !!}
    {!! Form::group('static', 'subject', 'Subject', $data['subject']) !!}
    {!! Form::group('static', 'message', 'Message', nl2br($data['message'])) !!}
    {!! Form::group('static', 'info', 'Info', nl2br($data['info'])) !!}
    {!! Form::group('static', 'sms', 'Sms', $data['sms']) !!}
@endsection