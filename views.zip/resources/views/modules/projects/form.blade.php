@extends('layouts.form')

@section('title', $title.' - Projects')

@section('page-header', 'Projects <small>'.$title.'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-lightbulb-o"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\ProjectController@index') !!}">Projects</a></li>
        <li class="active">{{ $title }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('select', 'client_id', 'Client Id', $data['client_id'], ['options' => DB::table('clients')->orderBy('id')->lists('id', 'id')]) !!}
    {!! Form::group('text', 'tag', 'Tag', $data['tag']) !!}
    {!! Form::group('text', 'name', 'Name', $data['name']) !!}
    {!! Form::group('textarea', 'notes', 'Notes', $data['notes']) !!}
    {!! Form::group('textarea', 'description', 'Description', $data['description']) !!}
    {!! Form::group('text', 'startdate', 'Startdate', $data['startdate']) !!}
    {!! Form::group('text', 'deadline', 'Deadline', $data['deadline']) !!}
    {!! Form::group('number', 'progress', 'Progress', $data['progress']) !!}
@endsection

@section('scripts')
    <script src="{!! url('vendor/jsvalidation/js/jsvalidation.js')!!}"></script>
    {!! JsValidator::formRequest('App\Http\Requests\Modules\ProjectRequest') !!}
@endsection