@extends('layouts.form')

@section('title', $title.' - ProjectsAdmins')

@section('page-header', 'ProjectsAdmins <small>'.$title.'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-adn"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\ProjectsAdminController@index') !!}">ProjectsAdmins</a></li>
        <li class="active">{{ $title }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('select', 'project_id', 'Project Id', $data['project_id'], ['options' => DB::table('projects')->orderBy('id')->lists('id', 'id')]) !!}
    {!! Form::group('select', 'admin_id', 'Admin Id', $data['admin_id'], ['options' => DB::table('users')->orderBy('id')->lists('id', 'id')]) !!}
@endsection

@section('scripts')
    <script src="{!! url('vendor/jsvalidation/js/jsvalidation.js')!!}"></script>
    {!! JsValidator::formRequest('App\Http\Requests\Modules\ProjectsAdminRequest') !!}
@endsection