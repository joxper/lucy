@extends('layouts.list')

@section('title', 'ProjectsAdmins')

@section('page-header', 'ProjectsAdmins <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-adn"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">ProjectsAdmins</li>
    </ol>
@endsection

@section('table-name', 'ProjectsAdmins List')

@section('add-link', action('Modules\ProjectsAdminController@create'))

@section('table-id', 'projects_admins-table')

@section('table-th')
    <th class="center-align">Project Id</th>
    <th class="center-align">Admin Id</th>
@endsection

@section('ajax-datatables', action('Modules\ProjectsAdminController@datatables'))

@section('datatables-columns')
    {data: 'project_id', name: 'project_id'},
    {data: 'admin_id', name: 'admin_id'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection