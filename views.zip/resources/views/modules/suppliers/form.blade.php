@extends('layouts.form')

@section('title', $title.' - Suppliers')

@section('page-header', 'Suppliers <small>'.$title.'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-skyatlas"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\SupplierController@index') !!}">Suppliers</a></li>
        <li class="active">{{ $title }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('text', 'name', 'Name', $data['name']) !!}
    {!! Form::group('textarea', 'address', 'Address', $data['address']) !!}
    {!! Form::group('text', 'contactname', 'Contactname', $data['contactname']) !!}
    {!! Form::group('text', 'phone', 'Phone', $data['phone']) !!}
    {!! Form::group('text', 'email', 'Email', $data['email']) !!}
    {!! Form::group('text', 'web', 'Web', $data['web']) !!}
    {!! Form::group('textarea', 'notes', 'Notes', $data['notes']) !!}
@endsection

@section('scripts')
    <script src="{!! url('vendor/jsvalidation/js/jsvalidation.js')!!}"></script>
    {!! JsValidator::formRequest('App\Http\Requests\Modules\SupplierRequest') !!}
@endsection