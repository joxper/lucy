@extends('layouts.list')

@section('title', 'Suppliers')

@section('page-header', 'Suppliers <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-skyatlas"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">Suppliers</li>
    </ol>
@endsection

@section('table-name', 'Suppliers List')

@section('add-link', action('Modules\SupplierController@create'))

@section('table-id', 'suppliers-table')

@section('table-th')
    <th class="center-align">Name</th>
    <th class="center-align">Address</th>
    <th class="center-align">Contactname</th>
    <th class="center-align">Phone</th>
    <th class="center-align">Email</th>
    <th class="center-align">Web</th>
    <th class="center-align">Notes</th>
@endsection

@section('ajax-datatables', action('Modules\SupplierController@datatables'))

@section('datatables-columns')
    {data: 'name', name: 'name'},
    {data: 'address', name: 'address'},
    {data: 'contactname', name: 'contactname'},
    {data: 'phone', name: 'phone'},
    {data: 'email', name: 'email'},
    {data: 'web', name: 'web'},
    {data: 'notes', name: 'notes'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection