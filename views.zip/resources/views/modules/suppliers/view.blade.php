@extends('layouts.view')

@section('title', trans('lucy.word.view').' - Suppliers')

@section('page-header', 'Suppliers <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-skyatlas"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\SupplierController@index') !!}">Suppliers</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'name', 'Name', $data['name']) !!}
    {!! Form::group('static', 'address', 'Address', nl2br($data['address'])) !!}
    {!! Form::group('static', 'contactname', 'Contactname', $data['contactname']) !!}
    {!! Form::group('static', 'phone', 'Phone', $data['phone']) !!}
    {!! Form::group('static', 'email', 'Email', $data['email']) !!}
    {!! Form::group('static', 'web', 'Web', $data['web']) !!}
    {!! Form::group('static', 'notes', 'Notes', nl2br($data['notes'])) !!}
@endsection