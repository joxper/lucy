@extends('layouts.list')

@section('title', 'test')

@section('page-header', 'test <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-adjust"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">test</li>
    </ol>
@endsection

@section('table-name', 'test List')

@section('add-link', action('Modules\TestController@create'))

@section('table-id', 'test-table')

@section('table-th')
    <th class="center-align">Test</th>
    <th class="center-align">Name</th>
@endsection

@section('ajax-datatables', action('Modules\TestController@datatables'))

@section('datatables-columns')
    {data: 'test', name: 'test'},
    {data: 'name', name: 'name'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection