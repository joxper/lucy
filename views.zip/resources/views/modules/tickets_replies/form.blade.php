@extends('layouts.form')

@section('title', $title.' - TicketsReplies')

@section('header')
    {!! Html::style('bower_components/AdminLTE/plugins/datepicker/datepicker3.css') !!}
@endsection

@section('page-header', 'TicketsReplies <small>'.$title.'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-mail-reply-all"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\TicketsReplyController@index') !!}">TicketsReplies</a></li>
        <li class="active">{{ $title }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('select', 'ticket_id', 'Ticket Id', $data['ticket_id'], ['options' => DB::table('tickets')->orderBy('id')->lists('id', 'id')]) !!}
    {!! Form::group('select', 'user_id', 'User Id', $data['user_id'], ['options' => DB::table('users')->orderBy('id')->lists('id', 'id')]) !!}
    {!! Form::group('textarea', 'message', 'Message', $data['message']) !!}
    {!! Form::group('text', 'timestamp', 'Timestamp', $data['timestamp'], ['readonly' => true, 'class' => 'lucy-date']) !!}
@endsection

@section('scripts')
    <script src="{!! url('vendor/jsvalidation/js/jsvalidation.js')!!}"></script>
    {!! JsValidator::formRequest('App\Http\Requests\Modules\TicketsReplyRequest') !!}
    {!! Html::script('bower_components/AdminLTE/plugins/datepicker/bootstrap-datepicker.js') !!}

    <script>
        $(document).ready(function () {
            $('.lucy-date').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
            });
        });
    </script>
@endsection