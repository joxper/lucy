@extends('layouts.list')

@section('title', 'TicketsReplies')

@section('page-header', 'TicketsReplies <small>'.trans('lucy.word.list').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-mail-reply-all"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li class="active">TicketsReplies</li>
    </ol>
@endsection

@section('table-name', 'TicketsReplies List')

@section('add-link', action('Modules\TicketsReplyController@create'))

@section('table-id', 'tickets_replies-table')

@section('table-th')
    <th class="center-align">Ticket Id</th>
    <th class="center-align">User Id</th>
    <th class="center-align">Message</th>
    <th class="center-align">Timestamp</th>
@endsection

@section('ajax-datatables', action('Modules\TicketsReplyController@datatables'))

@section('datatables-columns')
    {data: 'ticket_id', name: 'ticket_id'},
    {data: 'user_id', name: 'user_id'},
    {data: 'message', name: 'message'},
    {data: 'timestamp', name: 'timestamp'},
    {data: 'action', name: 'action', class: 'center-align', searchable: false, orderable: false}
@endsection