@extends('layouts.view')

@section('title', trans('lucy.word.view').' - TicketsRules')

@section('page-header', 'TicketsRules <small>'.trans('lucy.word.view').'</small>')

@section('breadcrumb')
    <ol class="breadcrumb">
        <li><a href="{!! action('DashboardController@index') !!}"><i class="fa fa-forumbee"></i> {{ trans('lucy.app.home') }}</a></li>
        <li><a href="#">{{ trans('lucy.word.modules') }}</a></li>
        <li><a href="{!! action('Modules\TicketsRuleController@index') !!}">TicketsRules</a></li>
        <li class="active">{{ trans('lucy.word.view') }}</li>
    </ol>
@endsection

@section('form')
    {!! Form::group('static', 'ticket_id', 'Ticket Id', $data['ticket_id']) !!}
    {!! Form::group('static', 'executed', 'Executed', $data['executed']) !!}
    {!! Form::group('static', 'name', 'Name', $data['name']) !!}
    {!! Form::group('static', 'cond_status', 'Cond Status', $data['cond_status']) !!}
    {!! Form::group('static', 'cond_priority', 'Cond Priority', $data['cond_priority']) !!}
    {!! Form::group('static', 'cond_timeelapsed', 'Cond Timeelapsed', $data['cond_timeelapsed']) !!}
    {!! Form::group('static', 'cond_datetime', 'Cond Datetime', $data['cond_datetime']) !!}
    {!! Form::group('static', 'act_status', 'Act Status', $data['act_status']) !!}
    {!! Form::group('static', 'act_priority', 'Act Priority', $data['act_priority']) !!}
    {!! Form::group('static', 'act_assignto', 'Act Assignto', $data['act_assignto']) !!}
    {!! Form::group('static', 'act_notifyadmins', 'Act Notifyadmins', $data['act_notifyadmins']) !!}
    {!! Form::group('static', 'act_addreply', 'Act Addreply', $data['act_addreply']) !!}
    {!! Form::group('static', 'reply', 'Reply', nl2br($data['reply'])) !!}
@endsection